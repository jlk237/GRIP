from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from db import run_query
from config import settings
import httpx

router = APIRouter()


@router.get("/{case_id}/timeline")
async def risk_timeline(case_id: str):
    return await run_query("""
        MATCH (p:Person {caseId: $caseId})-[:HAS_RISK_FLAG]->(rf:RiskFlag)
        RETURN rf.flagType AS flag, rf.severity AS severity,
               rf.iscScore AS isc, rf.description AS desc,
               rf.dateIdentified AS date
        ORDER BY rf.iscScore DESC
    """, {"caseId": case_id})


@router.get("/{case_id}/whole-person")
async def whole_person(case_id: str):
    """SEAD-4 whole person factors."""
    return await run_query("""
        MATCH (p:Person {caseId: $caseId})
        OPTIONAL MATCH (p)-[:HAS_RISK_FLAG]->(rf)
        OPTIONAL MATCH (p)-[:HAS_FINANCIAL_RECORD]->(f)
        OPTIONAL MATCH (p)-[:HAS_EMPLOYMENT_RECORD]->(e)
        OPTIONAL MATCH (p)-[:HAS_FOREIGN_CONTACT]->(fc)
        OPTIONAL MATCH (p)-[:HAS_LEGAL_RECORD]->(l)
        RETURN p,
               collect(DISTINCT rf) AS riskFlags,
               collect(DISTINCT f)  AS financials,
               collect(DISTINCT e)  AS employment,
               collect(DISTINCT fc) AS foreignContacts,
               collect(DISTINCT l)  AS legal
    """, {"caseId": case_id})


class DraftRequest(BaseModel):
    caseId: str


@router.post("/draft")
async def generate_draft(req: DraftRequest):
    """
    Generate an AI adjudication draft.
    Collects all subject data from Neo4j, builds the prompt,
    calls Claude API server-side, returns the draft text.
    """
    if not settings.ANTHROPIC_API_KEY:
        raise HTTPException(status_code=503, detail="ANTHROPIC_API_KEY not configured")

    # Gather all subject context from Neo4j
    subject = await run_query("""
        MATCH (p:Person {caseId: $caseId})
        OPTIONAL MATCH (p)-[:HAS_CLEARANCE_DETERMINATION]->(cd)-[:HAS_ADJUDICATION]->(adj)
        RETURN p, cd, adj
    """, {"caseId": req.caseId})

    if not subject:
        raise HTTPException(status_code=404, detail=f"Subject {req.caseId} not found")

    flags = await run_query("""
        MATCH (p:Person {caseId: $caseId})-[:HAS_RISK_FLAG]->(rf)-[:FALLS_UNDER]->(g)
        RETURN rf.flagType AS flag, rf.severity AS severity,
               rf.iscScore AS isc, rf.description AS desc,
               rf.mitigatingFactor AS mit, g.guidelineName AS guideline
    """, {"caseId": req.caseId})

    foreign = await run_query("""
        MATCH (p:Person {caseId: $caseId})-[:HAS_FOREIGN_CONTACT]->(fc)
        RETURN fc.contactName AS name, fc.country AS country,
               fc.relationship AS relationship, fc.notes AS notes
    """, {"caseId": req.caseId})

    history = await run_query("""
        MATCH (p:Person)-[:HAS_CLEARANCE_DETERMINATION]->(cd)-[:HAS_ADJUDICATION]->(adj)
        WHERE p.caseId <> $caseId
        OPTIONAL MATCH (p)-[:HAS_RISK_FLAG]->(rf) WHERE rf.flagType <> 'None'
        RETURN p.fullName AS name, p.riskScore AS riskScore,
               adj.adjudicationResult AS outcome, count(DISTINCT rf) AS flagCount
        ORDER BY p.riskScore DESC LIMIT 5
    """, {"caseId": req.caseId})

    p = subject[0].get("p", {})
    cd = subject[0].get("cd", {})
    adj = subject[0].get("adj", {})
    outcome = adj.get("adjudicationResult") or cd.get("recommendedDecision") or "Conditional Favorable"

    prompt = f"""You are a senior security adjudicator drafting a formal adjudication determination under SEAD-4 guidelines.

SUBJECT: {p.get('fullName')} | Case: {p.get('caseId')} | Clearance: {p.get('clearanceType')} | Agency: {p.get('clientAgency')}
Risk Score: {p.get('riskScore')}/10 | ISC Average: {p.get('iscAverage')}
Recommended Outcome: {outcome}

RISK FLAGS ({len(flags)} identified):
{chr(10).join(f"- {f['flag']} (Severity: {f['severity']}, ISC: {f['isc']}): {f['desc']} | Mitigation: {f['mit']} | Guideline: {f['guideline']}" for f in flags) or "None"}

FOREIGN CONTACTS ({len(foreign)}):
{chr(10).join(f"- {fc['name']} ({fc['country']}): {fc['relationship']} — {fc['notes']}" for fc in foreign) or "None"}

HISTORICAL COMPARISON (similar cases):
{chr(10).join(f"- {h['name']}: Risk {h['riskScore']}/10, {h['flagCount']} flags → {h['outcome']}" for h in history) or "No comparable cases"}

Generate a professional structured adjudication determination with these sections:
1. Case Summary
2. Issues of Concern — cite each risk flag with its guideline code
3. Mitigating Factors — cite specific evidence from the record
4. Whole Person Assessment — per SEAD-4
5. Determination — with any conditions or monitoring requirements
6. Rationale — consistency with similar cases

Write in formal government adjudication style, approximately 500 words. Be specific and cite the actual data provided."""

    async with httpx.AsyncClient(timeout=60.0) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-opus-4-6",
                "max_tokens": 1500,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Claude API error: {response.text}")

    data = response.json()
    draft_text = data["content"][0]["text"]

    return {
        "draft": draft_text,
        "subject": p,
        "outcome": outcome,
        "flagCount": len(flags),
        "model": data.get("model"),
        "usage": data.get("usage"),
    }


@router.get("/{case_id}/timeline")
async def risk_timeline(case_id: str):
    """
    Returns all life events merged and sorted by date:
    risk flags, employment, military service, education, legal records, adjudication.
    Each event has: type, date, title, subtitle, desc, color, isc (risk flags only)
    """
    events = []

    # Risk flags
    flags = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_RISK_FLAG]->(rf:RiskFlag)
        WHERE rf.flagType <> 'None'
        RETURN rf.flagType AS flag, rf.iscCode AS isc, rf.severity AS severity,
               rf.dateIdentified AS date, rf.description AS desc
    """, {"caseId": case_id})
    for f in flags:
        isc = f.get("isc") or 0
        try: isc = float(isc)
        except: isc = 0
        events.append({
            "type":     "risk",
            "date":     f.get("date") or "",
            "title":    f.get("flag") or "Risk Flag",
            "subtitle": f.get("severity") or "",
            "desc":     f.get("desc") or "",
            "isc":      isc,
            "color":    "red" if isc >= 4 else "yellow" if isc >= 2 else "accent",
        })

    # Employment
    emp = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_EMPLOYMENT_RECORD]->(e)
        RETURN e.employerName AS employer, e.positionTitle AS title,
               e.startDate AS start, e.endDate AS end, e.isCurrent AS current,
               e.employerAddress AS address
    """, {"caseId": case_id})
    for e in emp:
        date = e.get("start") or ""
        end  = e.get("end") or ("Present" if e.get("current") else "")
        events.append({
            "type":     "employment",
            "date":     date,
            "title":    e.get("title") or "Employment",
            "subtitle": e.get("employer") or "",
            "desc":     f"{date} — {end}".strip(" —") if (date or end) else "",
            "isc":      0,
            "color":    "green",
        })

    # Military service
    mil = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_MILITARY_SERVICE]->(m)
        RETURN m.branch AS branch, m.rank AS rank,
               m.startDate AS start, m.endDate AS end,
               m.dischargeType AS discharge
    """, {"caseId": case_id})
    for m in mil:
        events.append({
            "type":     "military",
            "date":     m.get("start") or "",
            "title":    f"{m.get('rank') or 'Military Service'} — {m.get('branch') or ''}".strip(" —"),
            "subtitle": m.get("discharge") or "",
            "desc":     f"{m.get('start') or ''} — {m.get('end') or 'Present'}".strip(" —"),
            "isc":      0,
            "color":    "blue",
        })

    # Education
    edu = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_EDUCATION_RECORD]->(e)
        RETURN e.institutionName AS school, e.degreeType AS degree,
               e.fieldOfStudy AS field, e.graduationDate AS date
    """, {"caseId": case_id})
    for e in edu:
        events.append({
            "type":     "education",
            "date":     e.get("date") or "",
            "title":    e.get("degree") or "Education",
            "subtitle": e.get("school") or "",
            "desc":     e.get("field") or "",
            "isc":      0,
            "color":    "purple",
        })

    # Legal / criminal records
    legal = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_LEGAL_RECORD]->(l)
        RETURN l.chargeType AS charge, l.disposition AS disposition,
               l.incidentDate AS date, l.jurisdiction AS jurisdiction
    """, {"caseId": case_id})
    for l in legal:
        events.append({
            "type":     "legal",
            "date":     l.get("date") or "",
            "title":    l.get("charge") or "Legal Record",
            "subtitle": l.get("disposition") or "",
            "desc":     l.get("jurisdiction") or "",
            "isc":      0,
            "color":    "orange",
        })

    # Adjudication outcome
    adj = await run_query("""
        MATCH (p:Person {caseId:$caseId})-[:HAS_CLEARANCE_DETERMINATION]->(cd)-[:HAS_ADJUDICATION]->(a)
        RETURN a.adjudicationResult AS result, a.adjudicationDate AS date,
               cd.clearanceType AS clearance
    """, {"caseId": case_id})
    for a in adj:
        result = a.get("result") or ""
        events.append({
            "type":     "adjudication",
            "date":     a.get("date") or "",
            "title":    result or "Adjudication",
            "subtitle": a.get("clearance") or "",
            "desc":     "Final adjudicative determination",
            "isc":      0,
            "color":    "red" if "Unfavorable" in result else "yellow" if "Conditional" in result else "green",
        })

    # Sort by date descending (most recent first), undated events last
    def sort_key(e):
        d = e.get("date") or ""
        return d if d else "0000"

    events.sort(key=sort_key, reverse=True)
    return events


@router.get("/{case_id}/whole-person")
async def whole_person(case_id: str):
    return await run_query("""
        MATCH (p:Person {caseId:$caseId})
        OPTIONAL MATCH (p)-[:HAS_RISK_FLAG]->(rf) WHERE rf.flagType <> 'None'
        OPTIONAL MATCH (p)-[:HAS_EMPLOYMENT_RECORD]->(e)
        OPTIONAL MATCH (p)-[:HAS_FINANCIAL_RECORD]->(fin)
        OPTIONAL MATCH (p)-[:HAS_FOREIGN_CONTACT]->(fc)
        OPTIONAL MATCH (p)-[:HAS_CLEARANCE_DETERMINATION]->(cd)-[:HAS_ADJUDICATION]->(adj)
        RETURN p {.fullName,.caseId,.riskScore,.iscAverage,.clearanceType,.clientAgency} AS p,
               collect(DISTINCT rf {.flagType,.iscCode,.severity,.mitigatingFactor}) AS riskFlags,
               collect(DISTINCT e {.employerName,.positionTitle,.isCurrent}) AS employment,
               collect(DISTINCT fin {.creditScore,.accountType,.status}) AS financials,
               collect(DISTINCT fc {.contactName,.country}) AS foreignContacts,
               adj.adjudicationResult AS outcome
    """, {"caseId": case_id})
