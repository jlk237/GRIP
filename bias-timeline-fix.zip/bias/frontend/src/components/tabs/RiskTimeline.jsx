import { useEffect, useRef } from 'react'
import * as d3 from 'd3'
import { useData } from '../../api/useData.js'
import { getTimeline } from '../../api/client.js'

// ── Colour map ────────────────────────────────────────────────────────────────
const COLOR = {
  red:    'var(--red)',
  yellow: 'var(--yellow)',
  green:  'var(--green)',
  accent: 'var(--accent)',
  blue:   '#4da6ff',
  purple: '#a78bfa',
  orange: '#ff7043',
}
const BG = {
  red:    'rgba(255,61,87,0.07)',
  yellow: 'rgba(255,196,0,0.06)',
  green:  'rgba(0,230,118,0.06)',
  accent: 'rgba(0,200,255,0.06)',
  blue:   'rgba(77,166,255,0.07)',
  purple: 'rgba(167,139,250,0.07)',
  orange: 'rgba(255,112,67,0.07)',
}

// ── Type config ───────────────────────────────────────────────────────────────
const TYPE_META = {
  risk:        { icon:'⚠',  label:'Risk Flag',        dotSize:16 },
  employment:  { icon:'💼', label:'Employment',        dotSize:14 },
  military:    { icon:'⭐', label:'Military Service',  dotSize:14 },
  education:   { icon:'🎓', label:'Education',         dotSize:14 },
  legal:       { icon:'⚖', label:'Legal Record',      dotSize:14 },
  adjudication:{ icon:'◈',  label:'Adjudication',      dotSize:18 },
}

// ── D3 accumulation chart — now uses event type coloring ─────────────────────
function TimelineChart({ data }) {
  const ref = useRef(null)

  useEffect(() => {
    if (!ref.current || !data?.length) return
    ref.current.innerHTML = ''

    // Count events per year, split by type
    const byYear = {}
    data.forEach(ev => {
      const yr = String(ev.date || '').substring(0, 4)
      if (!yr || yr === '0000') return
      if (!byYear[yr]) byYear[yr] = { risk:0, employment:0, military:0, education:0, legal:0, adjudication:0, total:0 }
      byYear[yr][ev.type] = (byYear[yr][ev.type] || 0) + 1
      byYear[yr].total++
    })

    const years = Object.keys(byYear).sort()
    if (!years.length) {
      ref.current.innerHTML = '<div style="color:var(--text3);font-family:var(--mono);font-size:12px;padding:20px;">No dated events to chart</div>'
      return
    }

    const maxVal = Math.max(...Object.values(byYear).map(v => v.total))
    const W = ref.current.clientWidth || 800, H = 200
    const margin = { top:24, right:20, bottom:32, left:40 }
    const iW = W - margin.left - margin.right
    const iH = H - margin.top  - margin.bottom

    const svg = d3.select(ref.current).append('svg').attr('width','100%').attr('height',H)
    const g   = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`)

    const x = d3.scaleBand().domain(years).range([0, iW]).padding(0.3)
    const y = d3.scaleLinear().domain([0, maxVal + 1]).range([iH, 0])

    // Gridlines
    g.append('g').selectAll('line').data(y.ticks(4)).join('line')
      .attr('x1',0).attr('x2',iW).attr('y1',d=>y(d)).attr('y2',d=>y(d))
      .attr('stroke','#1e3356').attr('stroke-dasharray','3,3')

    // Stacked bars per year
    const stackTypes = ['adjudication','legal','risk','military','employment','education']
    const stackColors = {
      risk:'rgba(255,61,87,0.7)', employment:'rgba(0,230,118,0.6)',
      military:'rgba(77,166,255,0.6)', education:'rgba(167,139,250,0.6)',
      legal:'rgba(255,112,67,0.65)', adjudication:'rgba(0,200,255,0.7)',
    }
    const stackBorder = {
      risk:'var(--red)', employment:'var(--green)',
      military:'#4da6ff', education:'#a78bfa',
      legal:'#ff7043', adjudication:'var(--accent)',
    }

    years.forEach(yr => {
      let yOffset = iH
      stackTypes.forEach(type => {
        const count = byYear[yr][type] || 0
        if (!count) return
        const barH = iH - y(count)
        yOffset -= barH
        g.append('rect')
          .attr('x', x(yr)).attr('y', yOffset)
          .attr('width', x.bandwidth()).attr('height', barH)
          .attr('fill', stackColors[type])
          .attr('stroke', stackBorder[type])
          .attr('stroke-width', 0.5).attr('rx', 1)
      })
      // Total label
      g.append('text')
        .attr('x', x(yr) + x.bandwidth()/2).attr('y', y(byYear[yr].total) - 4)
        .attr('text-anchor','middle').attr('font-size',10)
        .attr('font-family','Share Tech Mono,monospace').attr('fill','var(--text2)')
        .text(byYear[yr].total)
    })

    // Axes
    g.append('g').attr('transform',`translate(0,${iH})`).call(d3.axisBottom(x).tickSize(0))
      .selectAll('text').attr('fill','var(--text3)').attr('font-size',10).attr('font-family','Share Tech Mono,monospace')
    g.append('g').call(d3.axisLeft(y).ticks(4).tickSize(0))
      .selectAll('text').attr('fill','var(--text3)').attr('font-size',10).attr('font-family','Share Tech Mono,monospace')
    g.selectAll('.domain').attr('stroke','var(--border)')

    g.append('text').attr('x',iW/2).attr('y',-8).attr('text-anchor','middle')
      .attr('font-size',10).attr('font-family','Share Tech Mono,monospace')
      .attr('fill','var(--text3)').text('LIFE EVENTS BY YEAR')

    // Legend
    const legendItems = [
      ['risk','Risk Flag'], ['employment','Employment'], ['military','Military'],
      ['education','Education'], ['legal','Legal'], ['adjudication','Adjudication'],
    ]
    legendItems.forEach(([type, lbl], i) => {
      const lx = (i % 3) * (iW / 3)
      const ly = iH + 22 + Math.floor(i / 3) * 14
      g.append('rect').attr('x',lx).attr('y',ly-8).attr('width',10).attr('height',10)
        .attr('fill',stackColors[type]).attr('rx',1)
      g.append('text').attr('x',lx+14).attr('y',ly)
        .attr('font-size',9).attr('font-family','Share Tech Mono,monospace').attr('fill','var(--text3)').text(lbl)
    })
  }, [data])

  return <div ref={ref} style={{ width:'100%' }} />
}

// ── Single event row ──────────────────────────────────────────────────────────
function EventRow({ ev }) {
  const meta  = TYPE_META[ev.type] || TYPE_META.risk
  const color = COLOR[ev.color] || 'var(--accent)'
  const bg    = BG[ev.color]    || BG.accent

  return (
    <div style={{ position:'relative', marginBottom:'20px', paddingLeft:'20px' }}>
      {/* Dot */}
      <div style={{
        position:'absolute', left:`-${8 + meta.dotSize/2}px`, top:'6px',
        width:`${meta.dotSize}px`, height:`${meta.dotSize}px`,
        borderRadius:'50%', background:color,
        border:'2px solid var(--bg)',
        display:'flex', alignItems:'center', justifyContent:'center',
        fontSize: meta.dotSize > 14 ? '9px' : '7px',
        zIndex:1,
      }}>{ev.type === 'adjudication' ? '◈' : ''}</div>

      {/* Date */}
      <div style={{ fontFamily:'var(--mono)', fontSize:'10px', color:'var(--text3)', marginBottom:'4px' }}>
        {ev.date || '—'}
        <span style={{
          marginLeft:'8px', padding:'1px 6px', borderRadius:'2px', fontSize:'9px',
          background: bg, border:`1px solid ${color}33`,
          color, fontFamily:'var(--mono)',
        }}>{meta.label.toUpperCase()}</span>
      </div>

      {/* Card */}
      <div style={{
        background: bg,
        border: `1px solid ${color}33`,
        borderLeft: `3px solid ${color}`,
        borderRadius:'0 4px 4px 0',
        padding:'10px 14px',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:'8px', flexWrap:'wrap', marginBottom: ev.desc ? '4px' : 0 }}>
          <span style={{ fontSize:'16px' }}>{meta.icon}</span>
          <span style={{ fontSize:'13px', fontWeight:600, color }}>{ev.title}</span>
          {ev.subtitle && (
            <span style={{ fontFamily:'var(--mono)', fontSize:'11px', color:'var(--text3)' }}>{ev.subtitle}</span>
          )}
          {ev.isc > 0 && (
            <span className={`badge ${ev.isc>=4?'badge-critical':ev.isc>=2?'badge-moderate':'badge-low'}`}>
              ISC {ev.isc}
            </span>
          )}
        </div>
        {ev.desc && <div style={{ fontSize:'12px', color:'var(--text2)', lineHeight:1.6 }}>{ev.desc}</div>}
      </div>
    </div>
  )
}

// ── Main component ────────────────────────────────────────────────────────────
export default function RiskTimeline({ caseId }) {
  const { data, loading, error } = useData(() => getTimeline(caseId), [caseId])

  if (loading) return <div className="loading-text">LOADING TIMELINE...</div>
  if (error)   return <div className="error-text">Error: {error}</div>

  // Count by type for the filter summary
  const counts = {}
  ;(data||[]).forEach(ev => { counts[ev.type] = (counts[ev.type]||0)+1 })

  return (
    <div>
      <div style={{fontFamily:'var(--cond)',fontSize:'13px',letterSpacing:'2px',color:'var(--text3)',borderBottom:'1px solid var(--border)',paddingBottom:'10px',marginBottom:'16px'}}>
        <span style={{color:'var(--accent)'}}>Risk</span> Timeline
      </div>

      {/* Event type summary chips */}
      <div style={{ display:'flex', gap:'8px', flexWrap:'wrap', marginBottom:'16px' }}>
        {Object.entries(TYPE_META).map(([type, meta]) => {
          const count = counts[type] || 0
          if (!count) return null
          const color = { risk:'var(--red)', employment:'var(--green)', military:'#4da6ff', education:'#a78bfa', legal:'#ff7043', adjudication:'var(--accent)' }[type]
          return (
            <span key={type} style={{
              fontFamily:'var(--mono)', fontSize:'10px', padding:'3px 10px',
              background:`${color}18`, border:`1px solid ${color}44`,
              borderRadius:'2px', color,
            }}>
              {meta.icon} {meta.label} · {count}
            </span>
          )
        })}
      </div>

      {/* Chart */}
      <div className="card">
        <div className="card-title">◷ Life Events by Year</div>
        <TimelineChart data={data} />
      </div>

      {/* Timeline */}
      <div className="card">
        <div className="card-title">Chronological Event Timeline</div>
        <div style={{ position:'relative', paddingLeft:'40px' }}>
          {/* Vertical spine */}
          <div style={{ position:'absolute', left:'20px', top:0, bottom:0, width:'2px', background:'var(--border)' }} />

          {(data||[]).map((ev, i) => <EventRow key={i} ev={ev} />)}

          {(!data || data.length === 0) && (
            <div className="loading-text">No timeline events found for this subject</div>
          )}
        </div>
      </div>
    </div>
  )
}
